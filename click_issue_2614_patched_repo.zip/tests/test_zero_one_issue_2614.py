import click
from click.core import Command
from click.core import Option
from click.shell_completion import ShellComplete


def _get_words(cli, args, incomplete):
    comp = ShellComplete(cli, {}, cli.name, "_CLICK_COMPLETE")
    return [c.value for c in comp.get_completions(args, incomplete)]


def test_default_callback_not_called_during_completion():
    calls = []

    def default_callback():
        calls.append("called")
        return "expensive"

    cli = Command(
        "cli",
        params=[
            Option(["--name"], default=default_callback),
            Option(["--other"]),
        ],
    )

    assert _get_words(cli, [], "--") == ["--name", "--other", "--help"]
    assert calls == []
